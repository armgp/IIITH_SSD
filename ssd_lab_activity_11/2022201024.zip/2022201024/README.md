
# Lab 11 : Python Examples 
## File Handling
### Roll No: 2022201024


	(i) CSV file is read and the last 6 columns are dropped
	(ii) All the rows with negative %change of more than 3% is dropped using filter & lambda
		 function
	(iii) Average of Open, high, low for all the remaining rows are calculated using map &
		  lambda function and stored in a text file named avg_output.txt in the below given format.

			Open-Average = {value1}
			High-Average = {value2}
			Low-Average = {value3}

	

	(iv)&(v) Input is asked from the user to enter a charachter between A to Z. Once the iput is given
		 all the companies with names starting with the inputted letter along with their other column values are 
		 inputted into a text file named stock_output.txt. Example for this file format is given below

		 	ASIANPAINT  3 101.00  3 167.35  3 091.00  3 138.00  -6.25  -0.2
			AXISBANK  669  674.9  660.45  661  -18.9  -2.78

	
